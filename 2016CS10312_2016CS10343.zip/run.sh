#!/bin/bash
./runner
