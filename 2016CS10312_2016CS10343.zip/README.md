# YINSH_AI_bot
An AI bot to play the board game YINSH
